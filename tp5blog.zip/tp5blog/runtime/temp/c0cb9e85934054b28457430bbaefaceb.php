<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:73:"E:\xampp\htdocs\tp5blog\public/../application/index\view\index\index.html";i:1507083101;s:73:"E:\xampp\htdocs\tp5blog\public/../application/index\view\public\head.html";i:1507082005;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $title; ?></title>
    <link rel="stylesheet" href="__PUBLIC__/css/style.css">
</head>
<body>

<div class="header">
    <img src="__PUBLIC__/images/time.jpg" alt="">
</div>

<div class="nav">
    <ul>
        <li><a href="/">首页</a></li>
        <li><a href="/share">技术分享</a></li>
        <li><a href="/share">前端动态</a></li>
        <li><a href="/share">数据库知识</a></li>
        <li><a href="/share">node技术</a></li>
        <li><a href="/share">php教程</a></li>
        <li><a href="/share">TP5新篇</a></li>
    </ul>
</div>

 __PUBLIC__
<h1><?php echo $name; ?></h1>
<h3><?php echo $title; ?></h3>
<h2>我们的加</h2>
</body>
</html>