<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"E:\xampp\htdocs\tp5blog\public/../application/index\view\lists\List.html";i:1507078047;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<h1><?php echo $name; ?></h1>

<h2>List页面</h2>
</body>
</html>