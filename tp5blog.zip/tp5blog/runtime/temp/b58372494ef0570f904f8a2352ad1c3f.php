<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"E:\xampp\htdocs\tp5blog\public/../application/admin\view\index\index.html";i:1507083455;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>后台首页</title>
</head>
<body>
<h1><?php echo $name; ?></h1>

<h2>后台首页</h2>
</body>
</html>