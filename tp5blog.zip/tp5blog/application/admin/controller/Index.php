<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/9/28
 * Time: 11:53
 */

namespace app\admin\controller;
use think\Controller;

class Index extends Controller
{
    public function index()
    {
        $this->assign('name','zhujianwei');
        return  $this->fetch();

    }
}
