<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/10/4
 * Time: 8:43
 */
namespace app\index\controller;
use think\Controller;

class Article extends Controller
{
    public function index()
    {
        $this->assign('name','王者荣耀内容特');
        $this->assign('title','文章页');
        return  $this->fetch();

    }
}
