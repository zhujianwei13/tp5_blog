<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/10/4
 * Time: 9:20
 */

return [
    'view_replace_str'  =>  [
        '__PUBLIC__'=>SITE_URL.'/static/index',
        '__ROOT__' => '/',
    ]
];